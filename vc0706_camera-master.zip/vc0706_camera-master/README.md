# vc7060_camera
A python 3 driver for Adafruit IR camera running vc7060 chip

This was orginally listed in adafruit driver https://github.com/adafruit/Adafruit-VC0706-Serial-Camera-Library

Unfortunately the original code was designed for python 2. I had the opportunity to improve the code and port it to Python 3, and added few functions: 
- setsize(size)
- shoothi
- shootlo

Future improvement shall include:
- getsize
- setcompression
- getcompression

Please refer to www.linuxricle.com for awesome tips and tutorials on DIY IoT using Raspberry Pi and Arduino
